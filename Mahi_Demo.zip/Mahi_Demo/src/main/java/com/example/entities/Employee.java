package com.example.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="emplo_table")

public class Employee {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO )
    @Column(name="eid",length=105)
    private int eid;
    @Column(name="ename",length=95)
    private String ename;
    @Column(name="esal",length=50)
    private int esal;
    @Column(name="email",length=95)
    private String email;
    @Column(name="gender",length=15)
    private String gender;
    public int getEid() {
        return eid;
    }
    public void setEid(int eid) {
        this.eid = eid;
    }
    public String getEname() {
        return ename;
    }
    public void setEname(String ename) {
        this.ename = ename;
    }
    public int getEsal() {
        return esal;
    }
    public void setEsal(int esal) {
        this.esal = esal;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public Employee(int eid, String ename, int esal, String email, String gender) {
        super();
        this.eid = eid;
        this.ename = ename;
        this.esal = esal;
        this.email = email;
        this.gender = gender;
    }
    public Employee() {
        // TODO Auto-generated constructor stub
    }
    @Override
    public String toString() {
        return "Employee [eid=" + eid + ", ename=" + ename + ", esal=" + esal + ", email=" + email + ", gender="
                + gender + "]";
    }
    

 
}

