package com.example.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.Dao.IEmployeeDao;
import com.example.entities.Employee;


 

@org.springframework.stereotype.Service("Service")
public class EmployeeServiceImpl implements IEmployeeService{
    
    @Autowired
    private IEmployeeDao dao;
    @Override
    public Employee addEmployee(Employee employee) {
        dao.save(employee);
        return employee;
        
    }

 

    @Override
    public List<Employee> getAllEmployeesInfo() {
        return dao.findAll();
    }

    @Override
    public Employee getEmployeeById(int id) {
        return dao.findById(id).get();
    }
    @Override
    public void deleteById(int id) {
        dao.deleteById(id);
    }
}
 


