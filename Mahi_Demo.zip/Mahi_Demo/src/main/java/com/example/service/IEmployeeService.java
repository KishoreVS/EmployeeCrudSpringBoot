package com.example.service;
import java.util.List;

import com.example.entities.Employee;

public interface IEmployeeService {
    Employee addEmployee(Employee employee);
    List<Employee> getAllEmployeesInfo();
	Employee getEmployeeById(int id);
	void deleteById(int id);

 

}






 



 


    

