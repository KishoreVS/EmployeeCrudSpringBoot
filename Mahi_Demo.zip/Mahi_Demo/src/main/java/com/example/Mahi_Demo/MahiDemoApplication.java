package com.example.Mahi_Demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MahiDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MahiDemoApplication.class, args);
	}

}
