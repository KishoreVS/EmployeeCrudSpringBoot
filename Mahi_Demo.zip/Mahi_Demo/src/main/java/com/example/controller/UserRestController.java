package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entities.Employee;
import com.example.service.IEmployeeService;

 

@RestController
@RequestMapping("/users")
public class UserRestController {
    /** The JPA repository */
    @Autowired
    private IEmployeeService service;
    /**
     * Used to fetch all the users from DB
     * 
     * @return list of {@link User}
     */
    @GetMapping(value = "/{id}")
    public Employee findById(@PathVariable int id) {
        return service.getEmployeeById(id);
    }
    
    @GetMapping(value = "/all")
    public List<Employee> findAll() {
        return service.getAllEmployeesInfo();
    }
    /**
     * Used to create a User in the DB
     * 
     * @param users refers to the User needs to be saved
     * @return the {@link User} created
     */
    @PostMapping(value = "/load")
    public Employee load(@RequestBody final Employee users) {
        service.addEmployee(users);
        return service.addEmployee(users);
    }
    @DeleteMapping(value = "/{id}")
    public void deleteById(@PathVariable int id) {
        service.deleteById(id);
    }
    @PutMapping(value = "/update")
    public void update(@RequestBody final Employee users) {
    	service.addEmployee(users);
    }
}




